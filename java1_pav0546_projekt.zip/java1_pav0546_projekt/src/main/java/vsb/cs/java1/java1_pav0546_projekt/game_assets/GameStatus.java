package vsb.cs.java1.java1_pav0546_projekt.game_assets;

public enum GameStatus {
    STOPPED,
    PLAYABLE,
    PREGAME
}
